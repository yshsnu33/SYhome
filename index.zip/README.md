# 掌心窗公开版 v0.3.4.5

## 快速打包 APK

1. 点顶部的 **Actions** 标签
2. 点左侧 **Build Android Debug APK**
3. 点右侧 **Run workflow** → 绿色的 **Run workflow** 按钮
4. 等几分钟，构建完成后点进工作流，在底部 Artifacts 里下载 APK

## 部署后端

详见下方部署教程。